import bpy
import os
import pathlib


# --------------------------------------------------------------------------
#  GLOBAL CLIPBOARD + Helpers for Copy/Paste
# --------------------------------------------------------------------------

# This global dictionary will store pass settings after we click "Copy" on a layer.
RENDER_MANAGER_CLIPBOARD = {}


def gather_layer_settings(layer):
    """
    Gather pass properties from a given layer (and sub-objects if needed),
    storing them in a dict. Adjust or add pass properties as desired.
    """
    data = {}
    # Here we list all properties you might want to copy (both Cycles and Eevee).
    # For example, all these come from your “Data/Light Passes” and cryptomatte.
    # If a property doesn't exist on this layer, we skip it.
    # Modify or expand this list if needed.
    props_to_copy = [
        # Common:
        ("", "use_pass_combined"),
        ("", "use_pass_z"),
        ("", "use_pass_mist"),
        ("", "use_pass_normal"),
        ("", "use_pass_position"),
        ("", "use_pass_uv"),
        ("", "use_pass_object_index"),
        ("", "use_pass_material_index"),
        # Light passes:
        ("", "use_pass_shadow"),
        ("", "use_pass_ambient_occlusion"),
        ("", "use_pass_emit"),
        ("", "use_pass_environment"),
        ("", "use_pass_diffuse_direct"),
        ("", "use_pass_diffuse_indirect"),
        ("", "use_pass_diffuse_color"),
        ("", "use_pass_glossy_direct"),
        ("", "use_pass_glossy_indirect"),
        ("", "use_pass_glossy_color"),
        ("", "use_pass_transmission_direct"),
        ("", "use_pass_transmission_indirect"),
        ("", "use_pass_transmission_color"),
        ("", "use_pass_subsurface_direct"),
        ("", "use_pass_subsurface_indirect"),
        ("", "use_pass_subsurface_color"),
        # Cryptomatte:
        ("", "use_pass_cryptomatte_object"),
        ("", "use_pass_cryptomatte_material"),
        ("", "use_pass_cryptomatte_asset"),
        ("", "pass_cryptomatte_depth"),
        ("", "pass_cryptomatte_accurate"),
        # Eevee-specific:
        ("eevee", "use_pass_transparent"),
    ]

    for prop_path, prop_name in props_to_copy:
        container = getattr(layer, prop_path, None) if prop_path else layer
        if container and hasattr(container, prop_name):
            data[(prop_path, prop_name)] = getattr(container, prop_name)

    return data


def apply_layer_settings(layer, settings):
    """
    Apply the previously copied settings to layer.
    We skip any property that does not exist on this layer.
    """
    for (prop_path, prop_name), value in settings.items():
        container = getattr(layer, prop_path, None) if prop_path else layer
        if container and hasattr(container, prop_name):
            setattr(container, prop_name, value)


# --------------------------------------------------------------------------
#  Helpers to get/set the "render use" property for a View Layer
#    (unchanged from your script)
# --------------------------------------------------------------------------


def get_use_prop(view_layer):
    """Get the render toggle property (varies by Blender version)."""
    if hasattr(view_layer, "use"):
        return view_layer.use
    elif hasattr(view_layer, "use_for_render"):
        return view_layer.use_for_render
    return True


def set_use_prop(view_layer, value):
    """Set the render toggle property (varies by Blender version)."""
    if hasattr(view_layer, "use"):
        view_layer.use = value
    elif hasattr(view_layer, "use_for_render"):
        view_layer.use_for_render = value


# --------------------------------------------------------------------------
#  PASS DEFINITIONS + get_pass_groups_for_engine
#    (unchanged from your script so the spreadsheet still works)
# --------------------------------------------------------------------------

CYCLES_PASS_GROUPS = [
    (
        "Main Pass",
        [
            ("", "use_pass_combined", "Combined"),
        ],
    ),
    (
        "Data Passes",
        [
            ("", "use_pass_z", "Z"),
            ("", "use_pass_mist", "Mist"),
            ("", "use_pass_normal", "Normal"),
            ("", "use_pass_position", "Position"),
            ("", "use_pass_uv", "UV"),
            ("", "use_pass_object_index", "Object Index"),
            ("", "use_pass_material_index", "Material Index"),
        ],
    ),
    (
        "Light Passes",
        [
            ("", "use_pass_shadow", "Shadow"),
            ("", "use_pass_ambient_occlusion", "Ambient Occlusion"),
            ("", "use_pass_emit", "Emission"),
            ("", "use_pass_environment", "Environment"),
            ("", "use_pass_diffuse_direct", "Diffuse Direct"),
            ("", "use_pass_diffuse_indirect", "Diffuse Indirect"),
            ("", "use_pass_diffuse_color", "Diffuse Color"),
            ("", "use_pass_glossy_direct", "Glossy Direct"),
            ("", "use_pass_glossy_indirect", "Glossy Indirect"),
            ("", "use_pass_glossy_color", "Glossy Color"),
            ("", "use_pass_transmission_direct", "Transmission Direct"),
            ("", "use_pass_transmission_indirect", "Transmission Indirect"),
            ("", "use_pass_transmission_color", "Transmission Color"),
            ("", "use_pass_subsurface_direct", "Subsurface Direct"),
            ("", "use_pass_subsurface_indirect", "Subsurface Indirect"),
            ("", "use_pass_subsurface_color", "Subsurface Color"),
        ],
    ),
    (
        "Cryptomatte",
        [
            ("", "use_pass_cryptomatte_object", "Crypto Object"),
            ("", "use_pass_cryptomatte_material", "Crypto Material"),
            ("", "use_pass_cryptomatte_asset", "Crypto Asset"),
            ("", "pass_cryptomatte_depth", "Levels (Depth)"),
            ("", "pass_cryptomatte_accurate", "Accurate"),
        ],
    ),
]

EEVEE_PASS_GROUPS = [
    (
        "Main Pass",
        [
            ("", "use_pass_combined", "Combined"),
        ],
    ),
    (
        "Data Passes",
        [
            ("", "use_pass_combined", "Combined"),
            ("", "use_pass_z", "Z"),
            ("", "use_pass_mist", "Mist"),
            ("", "use_pass_normal", "Normal"),
            ("", "use_pass_position", "Position"),
            ("", "use_pass_vector", "Vector"),
        ],
    ),
    (
        "Light Passes",
        [
            ("", "use_pass_diffuse_direct", "Diffuse Light"),
            ("", "use_pass_diffuse_color", "Diffuse Color"),
            ("", "use_pass_glossy_direct", "Specular Light"),
            ("", "use_pass_glossy_color", "Specular Color"),
            ("", "use_pass_emit", "Emission"),
            ("", "use_pass_environment", "Environment"),
            ("", "use_pass_shadow", "Shadow"),
            ("", "use_pass_ambient_occlusion", "Ambient Occlusion"),
            ("eevee", "use_pass_transparent", "Transparent"),
        ],
    ),
    (
        "Cryptomatte",
        [
            ("", "use_pass_cryptomatte_object", "Crypto Object"),
            ("", "use_pass_cryptomatte_material", "Crypto Material"),
            ("", "use_pass_cryptomatte_asset", "Crypto Asset"),
            ("", "pass_cryptomatte_depth", "Levels (Depth)"),
            ("", "pass_cryptomatte_accurate", "Accurate"),
        ],
    ),
]


def get_pass_groups_for_engine(engine):
    """
    Return pass groups based on the engine name.
    Handles 'BLENDER_EEVEE_NEXT' or 'BLENDER_CYCLES' by substring check.
    """
    eng_up = engine.upper()
    if "CYCLES" in eng_up:
        return CYCLES_PASS_GROUPS
    elif "EEVEE" in eng_up:
        return EEVEE_PASS_GROUPS
    else:
        # Workbench or unknown engine
        return []


# --------------------------------------------------------------------------
#  Switch View Layer Operators
# --------------------------------------------------------------------------


class RENDER_MANAGER_OT_switch_layer(bpy.types.Operator):
    """Switch View Layer"""

    bl_idname = "render_manager.switch_view_layer"
    bl_label = "Switch View Layer"

    layer_index: bpy.props.IntProperty()

    def execute(self, context):
        scene = context.scene
        vl = scene.view_layers[self.layer_index]
        context.window.view_layer = vl

        for screen in bpy.data.screens:
            for area in screen.areas:
                area.tag_redraw()
        return {"FINISHED"}


# --------------------------------------------------------------------------
#  Reorder View Layer Operators
# --------------------------------------------------------------------------


class RENDER_MANAGER_OT_reorder_view_layer(bpy.types.Operator):
    """Reorder View Layer"""

    bl_idname = "render_manager.reorder_view_layer"
    bl_label = "Reorder View Layer"

    direction: bpy.props.EnumProperty(
        items=[
            ("UP", "Up", "Up"),
            ("DOWN", "Down", "Down"),
        ]
    )

    def execute(self, context):
        scene = context.scene
        active_index = None

        for i, vl in enumerate(context.scene.view_layers):
            if vl == context.view_layer:
                active_index = i
                break

        if self.direction == "DOWN":
            if len(context.scene.view_layers) > active_index + 1:
                vl = scene.view_layers.move(active_index, active_index + 1)
        if self.direction == "UP":
            if active_index - 1 >= 0:
                vl = scene.view_layers.move(active_index, active_index - 1)

        for screen in bpy.data.screens:
            for area in screen.areas:
                area.tag_redraw()
        return {"FINISHED"}


# --------------------------------------------------------------------------
#  COPY & PASTE Operators
# --------------------------------------------------------------------------


class RENDER_MANAGER_OT_copy_layer_settings(bpy.types.Operator):
    """Copy all pass settings from this View Layer into an internal clipboard"""

    bl_idname = "render_manager.copy_layer_settings"
    bl_label = "Copy Layer Settings"

    layer_index: bpy.props.IntProperty()

    def execute(self, context):
        scene = context.scene
        vl = scene.view_layers[self.layer_index]

        global RENDER_MANAGER_CLIPBOARD
        RENDER_MANAGER_CLIPBOARD = gather_layer_settings(vl)
        print(RENDER_MANAGER_CLIPBOARD)

        self.report({"INFO"}, f"Copied settings from layer '{vl.name}'.")
        return {"FINISHED"}


class RENDER_MANAGER_OT_paste_layer_settings(bpy.types.Operator):
    """Paste the previously copied pass settings into this View Layer"""

    bl_idname = "render_manager.paste_layer_settings"
    bl_label = "Paste Layer Settings"

    layer_index: bpy.props.IntProperty()

    def execute(self, context):
        global RENDER_MANAGER_CLIPBOARD

        scene = context.scene
        vl = scene.view_layers[self.layer_index]

        if not RENDER_MANAGER_CLIPBOARD:
            self.report({"WARNING"}, "No copied settings found. Please copy first.")
            return {"CANCELLED"}

        apply_layer_settings(vl, RENDER_MANAGER_CLIPBOARD)
        self.report({"INFO"}, f"Pasted settings onto layer '{vl.name}'.")
        return {"FINISHED"}


# --------------------------------------------------------------------------
#  Operator: Toggle Render Visibility (unchanged)
# --------------------------------------------------------------------------


class RENDER_MANAGER_OT_toggle_visibility(bpy.types.Operator):
    """Toggle the render visibility of a View Layer"""

    bl_idname = "render_manager.toggle_visibility"
    bl_label = "Toggle View Layer Visibility"

    layer_index: bpy.props.IntProperty()

    def execute(self, context):
        scene = context.scene
        vl = scene.view_layers[self.layer_index]
        set_use_prop(vl, not get_use_prop(vl))
        return {"FINISHED"}


# --------------------------------------------------------------------------
#  Operator: Render Layer Settings (the spreadsheet) - UNCHANGED
# --------------------------------------------------------------------------


class RENDER_MANAGER_OT_view_layer_settings(bpy.types.Operator):
    """Show a pop-up table to toggle passes per View Layer."""
    bl_idname = "render_manager.view_layer_settings"
    bl_label = "Render Layer Settings"
    bl_options = {"REGISTER", "UNDO"}

    def invoke(self, context, event):
        # Get the width of the entire Blender window
        screen_width = context.window.width  # Width of the entire Blender window
        
        # Calculate the maximum width for the dialog (screen width - 20 pixels for margin)
        max_width = screen_width - 20
        
        # Calculate the required width based on the number of view layers
        scene = context.scene
        view_layers = scene.view_layers
        num_view_layers = len(view_layers)
        
        # Base width for the first column and some padding
        base_width = 200
        
        # Additional width for each view layer column
        column_width = 100  # Adjust this value as needed
        total_width = base_width + (num_view_layers * column_width)
        
        # Ensure the width is within the calculated maximum
        width = min(total_width, max_width)
        
        return context.window_manager.invoke_props_dialog(self, width=width)

    def draw(self, context):
        # (The rest of the draw method remains unchanged)
        layout = self.layout
        scene = context.scene
        view_layers = scene.view_layers

        if not view_layers:
            layout.label(text="No View Layers found.")
            return

        engine = scene.render.engine  # e.g. "CYCLES", "BLENDER_EEVEE_NEXT"
        pass_groups = get_pass_groups_for_engine(engine)

        if not pass_groups:
            layout.label(text=f"No passes defined for engine: {engine}")
            return

        # (Rest of the draw method remains unchanged)
        # Table header row
        header = layout.row(align=True)
        split = header.split(factor=0.2, align=True)
        split.label(text="Passes")  # left column
        sub = split.split(factor=1.0, align=True)
        for i, vl in enumerate(view_layers):
            if i < len(view_layers) - 1:
                col_split = sub.split(factor=1.0 / (len(view_layers) - i), align=True)
                col_split.label(text=vl.name)
                sub = col_split
            else:
                sub.label(text=vl.name)

        # (Rest of the draw method remains unchanged)
        # Render On/Off and Copy/Paste Rows
        box_render_toggle = layout.box()
        box_render_toggle.label(text="Render / Copy-Paste Tools")

        # -- Row for "Rendering" checkboxes --
        row = box_render_toggle.row(align=True)
        row_split = row.split(factor=0.2, align=True)
        row_split.label(text="Rendering")  # left column label
        sub_rend = row_split.split(factor=1.0, align=True)
        for i, vl in enumerate(view_layers):
            if i < len(view_layers) - 1:
                col_split = sub_rend.split(
                    factor=1.0 / (len(view_layers) - i), align=True
                )
                # Try using vl.use first; if not present, use vl.use_for_render
                if hasattr(vl, "use"):
                    col_split.prop(vl, "use", text="")
                elif hasattr(vl, "use_for_render"):
                    col_split.prop(vl, "use_for_render", text="")
                else:
                    col_split.label(text="N/A")
                sub_rend = col_split
            else:
                # Last column
                if hasattr(vl, "use"):
                    sub_rend.prop(vl, "use", text="")
                elif hasattr(vl, "use_for_render"):
                    sub_rend.prop(vl, "use_for_render", text="")
                else:
                    sub_rend.label(text="N/A")

        # (Rest of the draw method remains unchanged)
        # -- Row for "Copy/Paste" buttons --
        row_cp = box_render_toggle.row(align=True)
        row_cp_split = row_cp.split(factor=0.2, align=True)
        row_cp_split.label(text="Copy/Paste")  # left column label
        sub_cp = row_cp_split.split(factor=1.0, align=True)
        for i, vl in enumerate(view_layers):
            if i < len(view_layers) - 1:
                col_split_cp = sub_cp.split(
                    factor=1.0 / (len(view_layers) - i), align=True
                )
                # We create a mini-row for the two icons
                row_icons = col_split_cp.row(align=True)
                op_copy = row_icons.operator(
                    "render_manager.copy_layer_settings", text="", icon="COPYDOWN"
                )
                op_copy.layer_index = i
                op_paste = row_icons.operator(
                    "render_manager.paste_layer_settings", text="", icon="PASTEDOWN"
                )
                op_paste.layer_index = i
                sub_cp = col_split_cp
            else:
                row_icons = sub_cp.row(align=True)
                op_copy = row_icons.operator(
                    "render_manager.copy_layer_settings", text="", icon="COPYDOWN"
                )
                op_copy.layer_index = i
                op_paste = row_icons.operator(
                    "render_manager.paste_layer_settings", text="", icon="PASTEDOWN"
                )
                op_paste.layer_index = i

        # (Rest of the draw method remains unchanged)
        # Show each pass group
        for group_title, pass_list in pass_groups:
            # Filter out passes that no View Layer has
            valid_rows = []
            for prop_path, prop_name, prop_label in pass_list:
                any_layer_has_it = False
                for vl in view_layers:
                    data_ref = getattr(vl, prop_path, None) if prop_path else vl
                    if data_ref and hasattr(data_ref, prop_name):
                        any_layer_has_it = True
                        break
                if any_layer_has_it:
                    valid_rows.append((prop_path, prop_name, prop_label))
            if not valid_rows:
                # Skip this entire group if no row is valid
                continue

            box = layout.box()
            box.label(text=group_title)
            for prop_path, prop_name, prop_label in valid_rows:
                row = box.row(align=True)
                row_split = row.split(factor=0.2, align=True)
                row_split.label(text=prop_label)
                sub2 = row_split.split(factor=1.0, align=True)
                for j, vl in enumerate(view_layers):
                    data_ref = getattr(vl, prop_path, None) if prop_path else vl
                    if j < len(view_layers) - 1:
                        subcol = sub2.split(
                            factor=1.0 / (len(view_layers) - j), align=True
                        )
                    else:
                        subcol = sub2
                    if data_ref and hasattr(data_ref, prop_name):
                        subcol.prop(data_ref, prop_name, text="")
                    else:
                        subcol.label(text="")  # Skip
                    sub2 = subcol

        # (Rest of the draw method remains unchanged)
        # Add Material Override, World Override, and Samples
        box_overrides = layout.box()
        box_overrides.label(text="View Layer Overrides")

        # Material Override
        row_material = box_overrides.row(align=True)
        row_material_split = row_material.split(factor=0.2, align=True)
        row_material_split.label(text="Material Override")
        sub_material = row_material_split.split(factor=1.0, align=True)
        for i, vl in enumerate(view_layers):
            if i < len(view_layers) - 1:
                col_split_material = sub_material.split(
                    factor=1.0 / (len(view_layers) - i), align=True
                )
            else:
                col_split_material = sub_material
            if hasattr(vl, "material_override"):
                col_split_material.prop(vl, "material_override", text="")
            else:
                col_split_material.label(text="N/A")
            sub_material = col_split_material

        # (Rest of the draw method remains unchanged)
        # World Override
        row_world = box_overrides.row(align=True)
        row_world_split = row_world.split(factor=0.2, align=True)
        row_world_split.label(text="World Override")
        sub_world = row_world_split.split(factor=1.0, align=True)
        for i, vl in enumerate(view_layers):
            if i < len(view_layers) - 1:
                col_split_world = sub_world.split(
                    factor=1.0 / (len(view_layers) - i), align=True
                )
            else:
                col_split_world = sub_world
            if hasattr(vl, "world_override"):
                col_split_world.prop(vl, "world_override", text="")
            else:
                col_split_world.label(text="N/A")
            sub_world = col_split_world

        # (Rest of the draw method remains unchanged)
        # Samples
        row_samples = box_overrides.row(align=True)
        row_samples_split = row_samples.split(factor=0.2, align=True)
        row_samples_split.label(text="Samples")
        sub_samples = row_samples_split.split(factor=1.0, align=True)
        for i, vl in enumerate(view_layers):
            if i < len(view_layers) - 1:
                col_split_samples = sub_samples.split(
                    factor=1.0 / (len(view_layers) - i), align=True
                )
            else:
                col_split_samples = sub_samples
            if hasattr(vl, "samples"):
                col_split_samples.prop(vl, "samples", text="")
            else:
                col_split_samples.label(text="N/A")
            sub_samples = col_split_samples

    def execute(self, context):
        return {"FINISHED"}


# --------------------------------------------------------------------------
#  Panel: Render Manager - Add Copy/Paste Buttons (new)
# --------------------------------------------------------------------------


class RENDER_MANAGER_PT_panel(bpy.types.Panel):
    """Panel to list and toggle View Layers, plus open pass settings"""

    bl_label = "Render Manager"
    bl_idname = "RENDER_MANAGER_PT_panel"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "view_layer"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        layout.label(text="View Layer Visibility:")
        main_row = layout.row()
        box = main_row.box()
        col = box.column()
        side_col = main_row.column(align=True)
        side_col.operator(
            "render_manager.add_render_layer",
            text="",
            icon="ADD",
        )
        side_col.operator(
            "render_manager.remove_render_layer",
            text="",
            icon="REMOVE",
        )
        side_col.separator()

        op = side_col.operator(
            "render_manager.reorder_view_layer", icon="TRIA_UP", text=""
        )
        op.direction = "UP"
        op = side_col.operator(
            "render_manager.reorder_view_layer", icon="TRIA_DOWN", text=""
        )
        op.direction = "DOWN"

        for i, vl in enumerate(context.scene.view_layers):
            row = col.row(align=True)
            if vl == context.view_layer:
                row.label(text="", icon="RADIOBUT_ON")
            else:
                op = row.operator(
                    "render_manager.switch_view_layer", text="", icon="RADIOBUT_OFF"
                )
                op.layer_index = i
            row.prop(vl, "name", text="")
            row.prop(vl, "use", text="", icon="RESTRICT_RENDER_OFF")
            op = row.operator(
                "render_manager.copy_layer_settings", text="", icon="COPYDOWN"
            )
            op.layer_index = i
            op = row.operator(
                "render_manager.paste_layer_settings", text="", icon="PASTEDOWN"
            )
            op.layer_index = i

        box.separator()
        layout.separator()

        # Add "Create Render Layer Settings" Button
               
        layout.operator(
            "render_manager.view_layer_settings",
            text="Render Layer Settings",
            icon="MODIFIER",
        )
        # Add "Create Render Nodes" Button
                        
        layout.operator(
            "render_manager.create_render_nodes",
            text="Create Render Nodes",
            icon="NODETREE",
        )



        side_col.separator()

        # Add all checkboxes in a column
        col = layout.column(align=True)
        col.prop(scene, "fixed_for_y_up")
        col.prop(scene, "combine_diff_glossy")
        col.prop(scene, "denoise")


# --------------------------------------------------------------------------
#  Operator: Create new layer
# --------------------------------------------------------------------------


class RENDER_MANAGER_OT_add_render_layer(bpy.types.Operator):
    """Add a new render layer"""

    bl_idname = "render_manager.add_render_layer"
    bl_label = "New Render Layer"
    bl_icon = "RENDERLAYERS"
    bl_options = {"UNDO", "REGISTER"}

    def execute(self, context):
        scene = context.scene
        try:
            new_layer = scene.view_layers.new(name="New Layer")
            context.window.view_layer = new_layer
            self.report({"INFO"}, f"Created new render layer: {new_layer.name}")
        except AttributeError:
            self.report(
                {"ERROR"}, "Unable to create a new render layer. Check Blender version."
            )
            return {"CANCELLED"}
        return {"FINISHED"}


# --------------------------------------------------------------------------
#  Operator: Remove layer
# --------------------------------------------------------------------------


class RENDER_MANAGER_OT_remove_render_layer(bpy.types.Operator):
    """Remove render layer"""

    bl_idname = "render_manager.remove_render_layer"
    bl_label = "Remove Render Layer"
    bl_icon = "RENDERLAYERS"
    bl_options = {"UNDO", "REGISTER"}

    @classmethod
    def poll(cls, context):
        if len(context.scene.view_layers) > 1:
            return True

    def execute(self, context):
        scene = context.scene
        scene.view_layers.remove(context.view_layer)

        return {"FINISHED"}


# --------------------------------------------------------------------------
#  Operator: Create Render Nodes
# --------------------------------------------------------------------------



def get_node_group_path():
    file_path = os.path.join(os.path.dirname(__file__), "node_groups.blend")
    return file_path


def ensure_y_up_node_groups():
    file_path = get_node_group_path()
    y_up_group = bpy.data.node_groups.get("Y-Up")

    if y_up_group is None:
        with bpy.data.libraries.load(get_node_group_path()) as (data_from, data_to):
            data_to.node_groups.append("Y-Up")

    y_up_group = bpy.data.node_groups.get("Y-Up")
    y_up_group.use_fake_user = True
    return y_up_group


def ensure_combine_pass_node_groups():
    file_path = get_node_group_path()
    node_group = bpy.data.node_groups.get("Combine_Passes")

    if node_group is None:
        with bpy.data.libraries.load(get_node_group_path()) as (data_from, data_to):
            data_to.node_groups.append("Combine_Passes")

    y_up_group = bpy.data.node_groups.get("Combine_Passes")
    y_up_group.use_fake_user = True
    return y_up_group


class RENDER_MANAGER_OT_create_render_nodes(bpy.types.Operator):
    """Create and connect file output nodes based on the selected File Handling mode."""

    bl_idname = "render_manager.create_render_nodes"
    bl_label = "Create Render Nodes"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = context.scene
        node_tree = scene.node_tree

        y_up = ensure_y_up_node_groups()
        combine_node = ensure_combine_pass_node_groups()

        # ✅ Ensure the compositor is enabled
        scene.use_nodes = True

        # ✅ Clear existing nodes
        node_tree.nodes.clear()

        # ✅ Define column and row spacing for structured node layout
        column_spacing = 300
        row_spacing = -600  # Adjusted for even node spacing
        previous_alpha_node = None

        composite_node = node_tree.nodes.new(type="CompositorNodeComposite")
        composite_node.location = (7 * column_spacing, 0)

        # ✅ Create render nodes
        for i, vl in enumerate(scene.view_layers):
            clean_layer_name = (
                vl.name.split("_", 1)[-1] if vl.name.startswith("layers_") else vl.name
            )
            x_pos = 0  # Keep first column aligned
            y_pos = i * row_spacing  # Arrange nodes in rows per layer

            # ✅ Create a unique Render Layers node for this layer
            per_layer_node = node_tree.nodes.new(type="CompositorNodeRLayers")
            per_layer_node.layer = vl.name
            per_layer_node.location = (x_pos, y_pos)

            # ✅ Handle Y-Up Fix for Normal and Position Passes
            normal_combine_xyz = None
            position_combine_xyz = None
            y_ups = {}

            if scene.fixed_for_y_up:
                # Check if Normal pass exists
                if "Normal" in per_layer_node.outputs:
                    y_up_node = node_tree.nodes.new("CompositorNodeGroup")
                    y_up_node.node_tree = y_up
                    y_up_node.location = (x_pos + column_spacing, y_pos)
                    y_ups["Normal"] = y_up_node

                    node_tree.links.new(
                        per_layer_node.outputs["Normal"], y_up_node.inputs[0]
                    )

                # Check if Position pass exists
                if "Position" in per_layer_node.outputs:
                    y_up_node = node_tree.nodes.new("CompositorNodeGroup")
                    y_up_node.node_tree = y_up
                    y_up_node.location = (x_pos + column_spacing, y_pos)
                    y_ups["Position"] = y_up_node

                    node_tree.links.new(
                        per_layer_node.outputs["Position"], y_up_node.inputs[0]
                    )

                    # position_separate_xyz = node_tree.nodes.new(
                    #     "CompositorNodeSeparateXYZ"
                    # )
                    # position_math_node = node_tree.nodes.new("CompositorNodeMath")
                    # position_combine_xyz = node_tree.nodes.new(
                    #     "CompositorNodeCombineXYZ"
                    # )
                    #
                    # position_separate_xyz.location = (
                    #     x_pos + column_spacing,
                    #     y_pos - 200,
                    # )
                    # position_math_node.location = (
                    #     x_pos + 2 * column_spacing,
                    #     y_pos - 200,
                    # )
                    # position_combine_xyz.location = (
                    #     x_pos + 3 * column_spacing,
                    #     y_pos - 200,
                    # )
                    #
                    # position_math_node.operation = "MULTIPLY"
                    # position_math_node.inputs[1].default_value = -1
                    #
                    # # Connect Position nodes
                    # node_tree.links.new(
                    #     per_layer_node.outputs["Position"],
                    #     position_separate_xyz.inputs[0],
                    # )
                    # node_tree.links.new(
                    #     position_separate_xyz.outputs[1], position_math_node.inputs[0]
                    # )
                    # node_tree.links.new(
                    #     position_math_node.outputs[0], position_combine_xyz.inputs[1]
                    # )
                    # node_tree.links.new(
                    #     position_separate_xyz.outputs[0], position_combine_xyz.inputs[0]
                    # )
                    # node_tree.links.new(
                    #     position_separate_xyz.outputs[2], position_combine_xyz.inputs[2]
                    # )

            # ✅ Handle Combine Diffuse, Glossy, and Transmission
            diffuse_combined_output = None
            glossy_combined_output = None
            transmission_combined_output = None

            if scene.combine_diff_glossy:
                # Combine Diffuse
                if all(
                    pass_name in per_layer_node.outputs
                    for pass_name in ["DiffDir", "DiffInd", "DiffCol"]
                ):
                    # add_diffuse_node = node_tree.nodes.new("CompositorNodeMixRGB")
                    # multiply_diffuse_node = node_tree.nodes.new("CompositorNodeMixRGB")
                    #
                    # add_diffuse_node.blend_type = "ADD"
                    # multiply_diffuse_node.blend_type = "MULTIPLY"
                    #
                    # add_diffuse_node.location = (x_pos + column_spacing, y_pos - 400)
                    # multiply_diffuse_node.location = (
                    #     x_pos + 2 * column_spacing,
                    #     y_pos - 400,
                    # )
                    #
                    # node_tree.links.new(
                    #     per_layer_node.outputs["DiffDir"], add_diffuse_node.inputs[1]
                    # )
                    # node_tree.links.new(
                    #     per_layer_node.outputs["DiffInd"], add_diffuse_node.inputs[2]
                    # )
                    # node_tree.links.new(
                    #     add_diffuse_node.outputs[0], multiply_diffuse_node.inputs[1]
                    # )
                    # node_tree.links.new(
                    #     per_layer_node.outputs["DiffCol"],
                    #     multiply_diffuse_node.inputs[2],
                    # )
                    #

                    combine_nodegroup = node_tree.nodes.new("CompositorNodeGroup")
                    combine_nodegroup.label = "Combine Diffuse"
                    combine_nodegroup.node_tree = combine_node
                    combine_nodegroup.location = (x_pos + column_spacing, y_pos - 200)

                    node_tree.links.new(
                        per_layer_node.outputs["DiffDir"], combine_nodegroup.inputs[0]
                    )
                    node_tree.links.new(
                        per_layer_node.outputs["DiffInd"], combine_nodegroup.inputs[1]
                    )
                    node_tree.links.new(
                        per_layer_node.outputs["DiffCol"],
                        combine_nodegroup.inputs[2],
                    )

                    diffuse_combined_output = combine_nodegroup.outputs[0]

                # Combine Glossy
                if all(
                    pass_name in per_layer_node.outputs
                    for pass_name in ["GlossDir", "GlossInd", "GlossCol"]
                ):
                    # add_glossy_node = node_tree.nodes.new("CompositorNodeMixRGB")
                    # multiply_glossy_node = node_tree.nodes.new("CompositorNodeMixRGB")
                    #
                    # add_glossy_node.blend_type = "ADD"
                    # multiply_glossy_node.blend_type = "MULTIPLY"
                    #
                    # add_glossy_node.location = (x_pos + column_spacing, y_pos - 500)
                    # multiply_glossy_node.location = (
                    #     x_pos + 2 * column_spacing,
                    #     y_pos - 500,
                    # )
                    #
                    # node_tree.links.new(
                    #     per_layer_node.outputs["GlossDir"], add_glossy_node.inputs[1]
                    # )
                    # node_tree.links.new(
                    #     per_layer_node.outputs["GlossInd"], add_glossy_node.inputs[2]
                    # )
                    # node_tree.links.new(
                    #     add_glossy_node.outputs[0], multiply_glossy_node.inputs[1]
                    # )
                    # node_tree.links.new(
                    #     per_layer_node.outputs["GlossCol"],
                    #     multiply_glossy_node.inputs[2],
                    # )

                    combine_nodegroup = node_tree.nodes.new("CompositorNodeGroup")
                    combine_nodegroup.label = "Combine Glossy"
                    combine_nodegroup.node_tree = combine_node
                    combine_nodegroup.location = (x_pos + column_spacing, y_pos - 300)

                    node_tree.links.new(
                        per_layer_node.outputs["GlossDir"], combine_nodegroup.inputs[0]
                    )
                    node_tree.links.new(
                        per_layer_node.outputs["GlossInd"], combine_nodegroup.inputs[1]
                    )
                    node_tree.links.new(
                        per_layer_node.outputs["GlossCol"],
                        combine_nodegroup.inputs[2],
                    )

                    glossy_combined_output = combine_nodegroup.outputs[0]

                # Combine Transmission
                if all(
                    pass_name in per_layer_node.outputs
                    for pass_name in ["TransDir", "TransInd", "TransCol"]
                ):
                    # add_transmission_node = node_tree.nodes.new("CompositorNodeMixRGB")
                    # multiply_transmission_node = node_tree.nodes.new(
                    #     "CompositorNodeMixRGB"
                    # )
                    #
                    # add_transmission_node.blend_type = "ADD"
                    # multiply_transmission_node.blend_type = "MULTIPLY"
                    #
                    # add_transmission_node.location = (
                    #     x_pos + column_spacing,
                    #     y_pos - 600,
                    # )
                    # multiply_transmission_node.location = (
                    #     x_pos + 2 * column_spacing,
                    #     y_pos - 600,
                    # )
                    #
                    # node_tree.links.new(
                    #     per_layer_node.outputs["TransDir"],
                    #     add_transmission_node.inputs[1],
                    # )
                    # node_tree.links.new(
                    #     per_layer_node.outputs["TransInd"],
                    #     add_transmission_node.inputs[2],
                    # )
                    # node_tree.links.new(
                    #     add_transmission_node.outputs[0],
                    #     multiply_transmission_node.inputs[1],
                    # )
                    # node_tree.links.new(
                    #     per_layer_node.outputs["TransCol"],
                    #     multiply_transmission_node.inputs[2],
                    # )

                    combine_nodegroup = node_tree.nodes.new("CompositorNodeGroup")
                    combine_nodegroup.node_tree = combine_node
                    combine_nodegroup.location = (x_pos + column_spacing, y_pos - 400)
                    combine_nodegroup.label = "Combine Transparency"

                    node_tree.links.new(
                        per_layer_node.outputs["TransDir"], combine_nodegroup.inputs[0]
                    )
                    node_tree.links.new(
                        per_layer_node.outputs["TransInd"], combine_nodegroup.inputs[1]
                    )
                    node_tree.links.new(
                        per_layer_node.outputs["TransCol"],
                        combine_nodegroup.inputs[2],
                    )

                    transmission_combined_output = combine_nodegroup.outputs[0]

            # ✅ Create File Output nodes for Color and Data
            layer_color_node = node_tree.nodes.new("CompositorNodeOutputFile")
            layer_data_node = node_tree.nodes.new("CompositorNodeOutputFile")
            layer_color_node.label = f"{clean_layer_name} Color Output"
            layer_data_node.label = f"{clean_layer_name} Data Output"

            layer_base_path = os.path.join(
                os.path.dirname(context.scene.render.filepath), clean_layer_name
            )
            layer_color_node.base_path = f"{layer_base_path}.####.exr"
            layer_data_node.base_path = f"{layer_base_path}_data.####.exr"

            layer_color_node.format.file_format = "OPEN_EXR_MULTILAYER"
            layer_data_node.format.file_format = "OPEN_EXR_MULTILAYER"
            layer_color_node.format.color_depth = "16"
            layer_data_node.format.color_depth = "32"

            layer_color_node.location = (x_pos + 4 * column_spacing, y_pos)
            layer_data_node.location = (x_pos + 5 * column_spacing, y_pos)

            # ✅ Create Alpha Over nodes for compositing
            alpha_over = None

            if i == 0:
                alpha_over = per_layer_node
            else:
                alpha_over = node_tree.nodes.new("CompositorNodeAlphaOver")
                alpha_over.location = (x_pos + 6 * column_spacing, y_pos)

                node_tree.links.new(
                    per_layer_node.outputs["Image"], alpha_over.inputs[2]
                )

            if alpha_over:
                if previous_alpha_node:
                    node_tree.links.new(
                        previous_alpha_node.outputs["Image"], alpha_over.inputs[1]
                    )

                previous_alpha_node = alpha_over

                # ✅ Connect "Image" output to _color file output
                node_tree.links.new(
                    per_layer_node.outputs["Image"], layer_color_node.inputs[0]
                )

            # ✅ Connect "Alpha" output if available
            if "Alpha" in per_layer_node.outputs:
                alpha_slot = layer_color_node.file_slots.new("Alpha")
                alpha_input = layer_color_node.inputs[-1]
                node_tree.links.new(per_layer_node.outputs["Alpha"], alpha_input)

            # ✅ Connect all passes to respective file outputs

            color_passes = [
                "DiffDir",
                "DiffInd",
                "DiffCol",
                "GlossDir",
                "GlossInd",
                "GlossCol",
                "TransDir",
                "TransInd",
                "TransCol",
                "Emit",
                "AO",
                "Env",
            ]
            data_passes = [
                "Depth",
                "Mist",
                "Position",
                "Normal",
                "UV",
                "IndexOB",
                "IndexMA",
                "CryptoObject00",
                "CryptoObject01",
                "CryptoObject02",
                "CryptoMaterial00",
                "CryptoMaterial01",
                "CryptoMaterial02",
                "CryptoAsset00",
                "CryptoAsset01",
                "CryptoAsset02",
            ]
            if scene.denoise:
                vl.use_pass_diffuse_color = True
                vl.use_pass_glossy_color = True
                vl.use_pass_transmission_color = True
                vl.use_pass_normal = True

            for pass_name in color_passes:
                if pass_name in per_layer_node.outputs:
                    # If combine_diff_glossy is enabled, use the combined outputs
                    if scene.combine_diff_glossy:
                        if pass_name == "DiffCol":
                            if diffuse_combined_output:
                                if scene.denoise:
                                    denoise_node = node_tree.nodes.new(
                                        "CompositorNodeDenoise"
                                    )
                                    denoise_node.label = "Denoise Diffuse"
                                    denoise_node.location = (
                                        x_pos + column_spacing + 300,
                                        y_pos + 200,
                                    )
                                    node_tree.links.new(
                                        diffuse_combined_output,
                                        denoise_node.inputs["Image"],
                                    )
                                    node_tree.links.new(
                                        per_layer_node.outputs["DiffCol"],
                                        denoise_node.inputs["Albedo"],
                                    )
                                    node_tree.links.new(
                                        per_layer_node.outputs["Normal"],
                                        denoise_node.inputs["Normal"],
                                    )
                                    node_tree.links.new(
                                        denoise_node.outputs[0],
                                        layer_data_node.inputs["Image"],
                                    )
                                    diffuse_combined_output = denoise_node.outputs[0]

                                diffuse_slot = layer_color_node.file_slots.new(
                                    "Diffuse"
                                )
                                diffuse_input = layer_color_node.inputs[-1]
                                node_tree.links.new(
                                    diffuse_combined_output, diffuse_input
                                )

                            continue  # Skip connecting DiffCol directly

                        if pass_name == "GlossCol":
                            if glossy_combined_output:
                                if scene.denoise:
                                    denoise_node = node_tree.nodes.new(
                                        "CompositorNodeDenoise"
                                    )
                                    denoise_node.label = "Denoise Gloss"
                                    denoise_node.location = (
                                        x_pos + column_spacing + 300,
                                        y_pos,
                                    )
                                    node_tree.links.new(
                                        glossy_combined_output,
                                        denoise_node.inputs["Image"],
                                    )
                                    node_tree.links.new(
                                        per_layer_node.outputs["GlossCol"],
                                        denoise_node.inputs["Albedo"],
                                    )
                                    node_tree.links.new(
                                        per_layer_node.outputs["Normal"],
                                        denoise_node.inputs["Normal"],
                                    )
                                    node_tree.links.new(
                                        denoise_node.outputs[0],
                                        layer_data_node.inputs["Image"],
                                    )
                                    glossy_combined_output = denoise_node.outputs[0]

                                glossy_slot = layer_color_node.file_slots.new("Glossy")
                                glossy_input = layer_color_node.inputs[-1]
                                node_tree.links.new(
                                    glossy_combined_output, glossy_input
                                )

                            continue  # Skip connecting GlossCol directly

                        if pass_name == "TransCol":
                            if transmission_combined_output:
                                if scene.denoise:
                                    denoise_node = node_tree.nodes.new(
                                        "CompositorNodeDenoise"
                                    )
                                    denoise_node.label = "Denoise Transparency"
                                    denoise_node.location = (
                                        x_pos + column_spacing + 300,
                                        y_pos - 200,
                                    )
                                    node_tree.links.new(
                                        transmission_combined_output,
                                        denoise_node.inputs["Image"],
                                    )
                                    node_tree.links.new(
                                        per_layer_node.outputs["TransCol"],
                                        denoise_node.inputs["Albedo"],
                                    )
                                    node_tree.links.new(
                                        per_layer_node.outputs["Normal"],
                                        denoise_node.inputs["Normal"],
                                    )
                                    node_tree.links.new(
                                        denoise_node.outputs[0],
                                        layer_data_node.inputs["Image"],
                                    )
                                    transmission_combined_output = denoise_node.outputs[
                                        0
                                    ]

                                transmission_slot = layer_color_node.file_slots.new(
                                    "Transmission"
                                )
                                transmission_input = layer_color_node.inputs[-1]
                                node_tree.links.new(
                                    transmission_combined_output, transmission_input
                                )
                            continue  # Skip connecting TransCol directly

                    if scene.denoise:
                        if pass_name in [
                            "DiffCol",
                            "DiffDir",
                            "DiffInd",
                            "GlossCol",
                            "GlossDir",
                            "GlossInd",
                            "TransCol",
                            "TransDir",
                            "TransInd",
                        ]:
                            continue

                    # Otherwise, connect the pass normally
                    color_slot = layer_color_node.file_slots.new(pass_name)
                    color_input = layer_color_node.inputs[-1]
                    node_tree.links.new(per_layer_node.outputs[pass_name], color_input)

            denoise_node = None
            if scene.denoise:
                denoise_node = node_tree.nodes.new("CompositorNodeDenoise")
                denoise_node.location = (x_pos + column_spacing, y_pos + 200)
                node_tree.links.new(
                    per_layer_node.outputs["Image"], denoise_node.inputs["Image"]
                )
                node_tree.links.new(
                    per_layer_node.outputs["DiffCol"], denoise_node.inputs["Albedo"]
                )
                node_tree.links.new(
                    per_layer_node.outputs["Normal"], denoise_node.inputs["Normal"]
                )
                node_tree.links.new(
                    denoise_node.outputs[0], layer_data_node.inputs["Image"]
                )

            for pass_name in data_passes:
                if pass_name in per_layer_node.outputs:
                    data_slot = layer_data_node.file_slots.new(pass_name)
                    data_input = layer_data_node.inputs[-1]

                    # If Fixed for Y-Up is enabled, use the Combine XYZ nodes for Normal and Position
                    if scene.fixed_for_y_up:
                        # if pass_name == "Normal" and y_up_node:
                        #     node_tree.links.new(y_up_node.outputs[0], data_input)
                        # elif pass_name == "Position" and position_combine_xyz:
                        #     node_tree.links.new(
                        #         position_combine_xyz.outputs[0], data_input
                        #     )
                        fallback = True
                        if pass_name == "Normal" and y_ups.get("Normal"):
                            node_tree.links.new(
                                y_ups.get("Normal").outputs[0], data_input
                            )
                            fallback = False
                        if pass_name == "Position" and y_ups.get("Position"):
                            node_tree.links.new(
                                y_ups.get("Position").outputs[0], data_input
                            )
                            fallback = False
                        if fallback:
                            node_tree.links.new(
                                per_layer_node.outputs[pass_name], data_input
                            )

                    else:
                        node_tree.links.new(
                            per_layer_node.outputs[pass_name], data_input
                        )

        # ✅ Connect last Alpha Over to Composite
        if previous_alpha_node:
            node_tree.links.new(
                previous_alpha_node.outputs["Image"], composite_node.inputs[0]
            )

        self.report(
            {"INFO"}, "Created node setup for all render layers in spreadsheet layout."
        )
        return {"FINISHED"}


# --------------------------------------------------------------------------
#  Registration
# --------------------------------------------------------------------------

classes = (
    RENDER_MANAGER_OT_create_render_nodes,
    RENDER_MANAGER_OT_copy_layer_settings,
    RENDER_MANAGER_OT_paste_layer_settings,
    RENDER_MANAGER_OT_toggle_visibility,
    RENDER_MANAGER_OT_view_layer_settings,
    RENDER_MANAGER_OT_add_render_layer,
    RENDER_MANAGER_OT_remove_render_layer,
    RENDER_MANAGER_OT_switch_layer,
    RENDER_MANAGER_PT_panel,
    RENDER_MANAGER_OT_reorder_view_layer,
)


def register():
    bpy.types.Scene.fixed_for_y_up = bpy.props.BoolProperty(
        name="Fixed for Y Up",
        description="Enable to fix the coordinate system for Y Up (Currently does nothing)",
        default=False,
    )

    bpy.types.Scene.combine_diff_glossy = bpy.props.BoolProperty(
        name="Combine Diff/Glossy/Trans",
        description="Combine diif and glossy channels together",
        default=True,
    )

    bpy.types.Scene.denoise = bpy.props.BoolProperty(
        name="Denoise",
        description="Denoises the passes",
        default=True,
    )

    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    del bpy.types.Scene.fixed_for_y_up
    del bpy.types.Scene.combine_diff_glossy
    del bpy.types.Scene.denoise
    # del bpy.types.Scene.render_manager_props

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
