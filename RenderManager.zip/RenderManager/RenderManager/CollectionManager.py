import bpy

# Define a custom PropertyGroup for storing expanded/collapsed state.
class ExpandedStateItem(bpy.types.PropertyGroup):
    """Custom PropertyGroup to store expanded/collapsed state."""
    # Set the default to False so that collections are collapsed by default.
    value: bpy.props.BoolProperty(default=False)

# Initialize custom properties.
def init_custom_properties():
    if not hasattr(bpy.types.Scene, "collection_spreadsheet_expanded"):
        bpy.types.Scene.collection_spreadsheet_expanded = bpy.props.CollectionProperty(
            type=ExpandedStateItem
        )

def get_expanded_state():
    """Get the expanded state dictionary."""
    scene = bpy.context.scene
    expanded_state = {}
    for item in scene.collection_spreadsheet_expanded:
        expanded_state[item.name] = item.value
    return expanded_state

def set_expanded_state(collection_name, value):
    """Set the expanded state for a collection."""
    scene = bpy.context.scene
    item = None
    for existing_item in scene.collection_spreadsheet_expanded:
        if existing_item.name == collection_name:
            item = existing_item
            break
    if not item:
        item = scene.collection_spreadsheet_expanded.add()
        item.name = collection_name
    item.value = value

def find_layer_collection_by_collection(root_layer_collection, collection):
    """Recursively find the LayerCollection whose .collection is the given `collection`."""
    if root_layer_collection.collection == collection:
        return root_layer_collection
    for child in root_layer_collection.children:
        found = find_layer_collection_by_collection(child, collection)
        if found:
            return found
    return None

def draw_collection(layout, vl, child_coll):
    """Draw the properties for a single collection in a view layer."""
    matching_lc = find_layer_collection_by_collection(vl.layer_collection, child_coll)
    if matching_lc:
        cell_row = layout.row(align=True)
        cell_row.prop(matching_lc, "exclude", text="", emboss=False)
        cell_row.prop(matching_lc, "holdout", text="", emboss=False)
        cell_row.prop(matching_lc, "indirect_only", text="", emboss=False)
    else:
        layout.label(text="N/A")

def draw_right_columns(layout, view_layers, draw_func):
    """
    Split the given layout evenly for each view layer.
    draw_func is a function receiving two arguments: (column, view_layer)
    """
    # Create a row in which we will split off each view layer cell.
    row = layout.row(align=True)
    num_vls = len(view_layers)
    # Use successive splits to carve out each cell.
    for i, vl in enumerate(view_layers):
        factor = 1.0 / (num_vls - i)
        split = row.split(factor=factor, align=True)
        col = split.column(align=True)
        draw_func(col, vl)
        row = split

def draw_recursive_collections(layout, view_layers, collection, level=0):
    """Recursively draw collections with collapsible behavior using a two-column layout."""
    expanded_state = get_expanded_state()
    # Default to False (collapsed) if not found.
    is_expanded = expanded_state.get(collection.name, False)

    # Create one row and split it into two parts:
    #   left: fixed column for the collection name (with indentation and toggle)
    #   right: container for view layer properties.
    main_row = layout.row(align=True)
    split = main_row.split(factor=0.3, align=True)
    left = split.column()
    right = split.column()

    # Left column: indentation, toggle button, and collection name.
    left_row = left.row(align=True)
    for _ in range(level):
        left_row.label(text="", icon="BLANK1")
    icon = "TRIA_DOWN" if is_expanded else "TRIA_RIGHT"
    op = left_row.operator("render_manager.toggle_expand", text="", icon=icon, emboss=False)
    op.collection_name = collection.name
    left_row.label(text=collection.name, icon="OUTLINER_COLLECTION")

    # Right column: for each view layer, create an evenly split cell.
    def draw_cell(col, vl):
        draw_collection(col, vl, collection)
    draw_right_columns(right, view_layers, draw_cell)

    # Recursively draw children if expanded.
    if is_expanded:
        for child in collection.children:
            draw_recursive_collections(layout, view_layers, child, level + 1)

class RENDER_MANAGER_OT_toggle_expand(bpy.types.Operator):
    """Toggle the expanded/collapsed state of a collection."""
    bl_idname = "render_manager.toggle_expand"
    bl_label = "Toggle Expand"
    bl_options = {"INTERNAL"}

    collection_name: bpy.props.StringProperty()

    def execute(self, context):
        expanded_state = get_expanded_state()
        current_state = expanded_state.get(self.collection_name, False)
        set_expanded_state(self.collection_name, not current_state)
        return {"FINISHED"}

class RENDER_MANAGER_OT_collection_spreadsheet(bpy.types.Operator):
    """Popup with rows = child collections, columns = view layers."""
    bl_idname = "render_manager.collection_spreadsheet"
    bl_label = "Collection Spreadsheet (Exclude & Eye, Aligned)"
    bl_options = {"REGISTER", "UNDO"}

    def invoke(self, context, event):
        scene = context.scene
        # Clear the expanded state so that all collections are collapsed by default.
        if hasattr(scene, "collection_spreadsheet_expanded"):
            scene.collection_spreadsheet_expanded.clear()
        view_layers = scene.view_layers
        num_view_layers = len(view_layers)
        base_width = 200
        column_width = 120
        total_width = base_width + num_view_layers * column_width
        max_width = context.window.width - 20
        width = min(total_width, max_width)
        return context.window_manager.invoke_props_dialog(self, width=width)

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        view_layers = scene.view_layers
        if not view_layers:
            layout.label(text="No View Layers found.")
            return

        # --- HEADER ---
        header = layout.row(align=True)
        split = header.split(factor=0.3, align=True)
        left = split.column()
        right = split.column()
        left.label(text="Collections")
        
        # For the right part, split evenly for each view layer.
        def draw_header_cell(col, vl):
            col.label(text=vl.name, icon="RENDERLAYERS")
        draw_right_columns(right, view_layers, draw_header_cell)

        # --- TABLE ROWS ---
        scene_children = scene.collection.children
        if not scene_children:
            layout.label(text="No sub-collections under the Scene Collection.", icon="INFO")
            return

        for child_coll in scene_children:
            draw_recursive_collections(layout, view_layers, child_coll)

    def execute(self, context):
        return {"FINISHED"}

def register():
    bpy.utils.register_class(ExpandedStateItem)
    init_custom_properties()
    bpy.utils.register_class(RENDER_MANAGER_OT_toggle_expand)
    bpy.utils.register_class(RENDER_MANAGER_OT_collection_spreadsheet)

def unregister():
    bpy.utils.unregister_class(RENDER_MANAGER_OT_collection_spreadsheet)
    bpy.utils.unregister_class(RENDER_MANAGER_OT_toggle_expand)
    bpy.utils.unregister_class(ExpandedStateItem)

if __name__ == "__main__":
    register()
